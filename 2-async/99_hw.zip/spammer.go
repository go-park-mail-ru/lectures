package main

func RunPipeline(cmds ...cmd) {

}

func SelectUsers(in, out chan interface{}) {
	// 	in - string
	// 	out - User
}

func SelectMessages(in, out chan interface{}) {
	// 	in - User
	// 	out - MsgID
}

func CheckSpam(in, out chan interface{}) {
	// in - MsgID
	// out - MsgData
}

func CombineResults(in, out chan interface{}) {
	// in - MsgData
	// out - string
}
